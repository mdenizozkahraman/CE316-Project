#include <stdio.h>

int main() {
    printf("Deniz Özkahraman");
    return 0;
}
