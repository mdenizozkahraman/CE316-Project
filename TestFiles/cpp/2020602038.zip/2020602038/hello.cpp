#include <iostream>

int main() {
    std::cout << "Hello, World! C++" << std::endl;
    return 0;
}
